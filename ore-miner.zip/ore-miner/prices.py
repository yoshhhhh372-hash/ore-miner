﻿def get_sol_price_usd():
    return 180.0

def get_ore_price_usd():
    return 3.0
