﻿import csv, time, os
def log_round(result):
    print(f'[LOG] {result}')
