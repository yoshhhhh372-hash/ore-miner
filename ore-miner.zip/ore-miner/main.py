﻿import time
from ore_api import get_round_snapshot, deploy
from strategy import pick_tiles, simulate_profit, init_log, record_profit

def run_loop():
    print("Starting simulated mining loop...\n")
    init_log()
    total_pnl = 0.0
    round_counter = 1

    while True:
        # Fetch current round snapshot
        round_data = get_round_snapshot()
        round_id = round_data.get("round_id", 0)

        # Decide which tiles to deploy
        chosen_tiles = pick_tiles(round_data)

        # Simulate deployments (no real tx)
        for tile_id in chosen_tiles:
            deploy(tile_id, 0.01)

        # Simulate profit
        profit = simulate_profit(chosen_tiles)
        total_pnl += profit

        # Log + print
        print(f"[Round {round_counter}] Profit: {profit:.4f} | Total PnL: {total_pnl:.4f}\n")
        record_profit(round_id, chosen_tiles, profit, total_pnl)

        round_counter += 1
        time.sleep(5)  # wait before next round (adjust as needed)

if __name__ == "__main__":
    run_loop()
