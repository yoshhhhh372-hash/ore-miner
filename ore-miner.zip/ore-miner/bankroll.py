﻿class Bankroll:
    def __init__(self):
        self.pnl = 0.0

    def update(self, profit):
        self.pnl += profit
