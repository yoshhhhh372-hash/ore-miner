# ore-miner
Automated Solana ORE mining bot with data tracking and strategy testing (private).
