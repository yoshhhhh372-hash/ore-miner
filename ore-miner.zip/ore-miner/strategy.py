﻿import random
import csv
import os
from datetime import datetime

LOG_FILE = "miner_log.csv"

def init_log():
    """Initialize CSV log if not exists"""
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "round_id", "tiles", "profit", "total_pnl"])


def pick_tiles(round_data):
    """
    Simple strategy:
    - Sort tiles by SOL deployed ascending
    - Pick top 3 least-deployed tiles (potentially higher reward chance)
    """
    tiles_sorted = sorted(round_data["tiles"], key=lambda t: t["sol_deployed"])
    chosen = [t["id"] for t in tiles_sorted[:3]]
    print(f"[STRATEGY] Picked tiles (lowest SOL deployed): {chosen}")
    return chosen


def simulate_profit(deployed_tiles):
    """
    Simulate pseudo-profit per round.
    For now: random small gain (0.0001–0.0005) per deployed tile.
    """
    base_profit = sum([random.uniform(0.0001, 0.0005) for _ in deployed_tiles])
    return round(base_profit, 4)


def record_profit(round_id, deployed_tiles, profit, total_pnl):
    """Append result to CSV log"""
    with open(LOG_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            round_id,
            ",".join(map(str, deployed_tiles)),
            profit,
            total_pnl
        ])
